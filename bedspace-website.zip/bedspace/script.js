// Footer year
document.getElementById("year").textContent = new Date().getFullYear();

// Lightbox gallery
const images = Array.from(document.querySelectorAll(".gallery img"));
const lightbox = document.getElementById("lightbox");
const lightboxImg = document.getElementById("lightbox-img");
let current = 0;

function show(index) {
  current = (index + images.length) % images.length;
  lightboxImg.src = images[current].src;
  lightboxImg.alt = images[current].alt;
}

function open(index) {
  show(index);
  lightbox.classList.add("open");
  lightbox.setAttribute("aria-hidden", "false");
}

function close() {
  lightbox.classList.remove("open");
  lightbox.setAttribute("aria-hidden", "true");
}

images.forEach((img, i) => img.addEventListener("click", () => open(i)));

lightbox.querySelector(".close").addEventListener("click", close);
lightbox.querySelector(".prev").addEventListener("click", () => show(current - 1));
lightbox.querySelector(".next").addEventListener("click", () => show(current + 1));

lightbox.addEventListener("click", (e) => {
  if (e.target === lightbox) close();
});

document.addEventListener("keydown", (e) => {
  if (!lightbox.classList.contains("open")) return;
  if (e.key === "Escape") close();
  if (e.key === "ArrowLeft") show(current - 1);
  if (e.key === "ArrowRight") show(current + 1);
});
